# Pan-Cancer Tissue-of-Origin Thesis Starter

A reproducible Python project for the first phase of a pan-cancer thesis:

1. Download a public **TCGA Pan-Cancer RNA-seq** matrix and phenotype table automatically.
2. Audit labels, class balance, missingness, and expression dimensions.
3. Prepare a leakage-safe primary-tumor dataset.
4. Train three baseline classifiers.
5. Train a hierarchical tissue-family → tumor-type classifier.
6. Produce figures, metrics, trained pipelines, and a manifest of every experiment.
7. Provide a safe template for independent external validation.

> **Research use only.** This is not a clinical diagnostic system. Do not use its predictions for patient care.

## Dataset and why this project uses it

The default source is the **UCSC Xena Toil recompute** RNA-seq TPM matrix spanning TCGA, TARGET, and GTEx, intersected in code with the TCGA phenotype table; the preparation script then retains TCGA primary-tumor samples. This joint processing makes it suitable for later cross-cohort work, while the first classifier remains TCGA-only. Xena distributes easy-to-use files derived from TCGA/GDC and documents its Pan-Cancer expression resources at https://xena.ucsc.edu/ and https://ucsc-xena.gitbook.io/project/faq/advanced-data-and-datasets . The official source and clinical-resource documentation are at https://gdc.cancer.gov/about-data/publications/pancanatlas .

The first run downloads the data **by code**. You do not need to download it manually. The downloader saves the exact URLs, date/time, file sizes, and SHA-256 checksums to `data/raw/download_manifest.json`.

The Xena matrix is a practical, normalized starting point. For a methods paper, you must still compare preprocessing strategies and validate on independent data; do not describe the matrix as universally “fully preprocessed.”

## Folder map

```text
pan-cancer-thesis-starter/
├── config/default.yaml              # Main experiment settings
├── data/
│   ├── raw/                         # Downloaded source files (gitignored)
│   ├── processed/                   # Split matrices and labels (gitignored)
│   └── external/                    # Independent cohorts + labels (gitignored)
├── docs/RESEARCH_PLAN.md            # Thesis question and experimental plan
├── notebooks/                       # Optional exploration notebooks
├── outputs/
│   ├── figures/                     # PNG plots
│   ├── metrics/                     # CSV/JSON evaluation results
│   └── models/                      # Serialized fitted pipelines
├── scripts/                         # Run these in numbered order
└── src/pancancer/                   # Reusable package code
```

## 1. Requirements

- Python **3.10–3.12**
- 8 GB RAM minimum; 16 GB recommended
- 8–12 GB free disk during the first run
- Internet access for the download

### Open in VS Code

1. Unzip this project.
2. Open the `pan-cancer-thesis-starter` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Run the commands below from the project root.

### Create and activate an environment

**Windows PowerShell**

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

**macOS / Linux**

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

In VS Code, select `.venv` as the Python interpreter when prompted.

## 2. Run the project in order

Run **one command at a time**. Inspect the outputs before moving on.

```bash
python scripts/00_download_data.py
python scripts/01_data_audit.py
python scripts/02_prepare_data.py
python scripts/03_train_baselines.py
python scripts/04_train_hierarchical.py
```

The full first run may take 30–90 minutes, depending on download speed and computer hardware. The heaviest step is reading and transposing the full expression matrix.

### What each script does

| Script | Purpose | Main output |
|---|---|---|
| `00_download_data.py` | Downloads the matrix and phenotype file; creates checksums | `data/raw/` |
| `01_data_audit.py` | Checks data shape, labels, class balance, duplicate IDs | `outputs/figures/class_distribution.png` |
| `02_prepare_data.py` | Keeps primary tumors, aligns labels, filters genes, splits data | `data/processed/` |
| `03_train_baselines.py` | Trains logistic regression, linear SVM, random forest | metrics, figures, models |
| `04_train_hierarchical.py` | Trains tissue-family → tumor-type model | hierarchy metrics and model |

## 3. Expected outputs

After a successful baseline run, inspect:

- `outputs/metrics/baseline_summary.csv`
- `outputs/metrics/baseline_per_class.csv`
- `outputs/figures/baseline_confusion_matrix_<model>.png`
- `outputs/metrics/hierarchical_summary.json`
- `outputs/figures/hierarchical_confusion_matrix.png`
- `outputs/models/`

Do not report only accuracy. Your report should emphasize **macro-F1**, balanced accuracy, per-class recall, confusion matrices, and errors among related tumors.

## 4. Important safeguards against leakage

This project:

- splits samples before fitting scalers or selecting features;
- fits scaling and feature selection on the training fold only;
- retains a held-out internal test set;
- uses stratified splits;
- saves the fitted pipeline so identical preprocessing is applied at inference.

Do **not** modify code to normalize, select top genes, or fit PCA using the complete dataset before the split. That will inflate results.

## 5. Configuration

Change settings in `config/default.yaml`, not inside the training scripts.

Good first experiments:

```yaml
features_to_keep: 1000
random_seed: 42
min_samples_per_class: 20
```

Then compare `features_to_keep: 500`, `1000`, and `2000`, one run at a time. Keep a dated experiment log and do not overwrite published results without recording the new settings.

## 6. External validation — do this only after the baseline works

The source project includes `scripts/05_external_validation_template.py`. It deliberately refuses to guess labels from an external dataset.

To run external validation you need:

1. a numeric expression matrix, samples × genes;
2. a curated label CSV with `sample_id` and `cancer_type`;
3. the frozen TCGA-trained model;
4. an explicit gene-ID mapping procedure.

Place files in `data/external/`, edit the paths in the script, then run:

```bash
python scripts/05_external_validation_template.py
```

Use an independent cohort such as GEO, CPTAC, or ICGC only after documenting platform, sample type, primary/metastatic status, label source, and gene-ID mapping. **Never retrain the TCGA model on an external test cohort before calculating the main external metric.**

## 7. Recommended research sequence

1. Reproduce the baseline exactly.
2. Compare 500/1,000/2,000 selected genes.
3. Compare flat vs hierarchical classification.
4. Add calibrated probabilities and a reject/abstention threshold.
5. Evaluate an independent cohort.
6. Add biological feature stability and pathway analysis.
7. Consider multi-omics only after the RNA-only pipeline is complete.

Read `docs/RESEARCH_PLAN.md` before changing the project direction.

## 8. Troubleshooting

### `No usable label column found`
The Xena phenotype table format may change. Open `outputs/metrics/audit_summary.json` and inspect `phenotype_columns`. Add the actual label field to `label_column_candidates` in `config/default.yaml`.

### Out-of-memory error
Set `features_to_keep: 500`, close other programs, and use a machine with 16 GB RAM. The source matrix is intentionally large.

### Download interrupted
Run `python scripts/00_download_data.py` again. It resumes/reuses a valid file when possible.

### Small class error during splitting
Increase `min_samples_per_class` or change split proportions. Do not remove rare classes silently; record every exclusion in `outputs/metrics/preparation_report.json`.

## Citation / provenance

- NCI GDC, TCGA Pan-Cancer Atlas: https://gdc.cancer.gov/about-data/publications/pancanatlas
- UCSC Xena: https://xena.ucsc.edu/
- Hoadley et al., *Cell* (2018), “Cell-of-Origin Patterns Dominate the Molecular Classification of 10,000 Tumors from 33 Types of Cancer.” DOI: 10.1016/j.cell.2018.03.022
- Your provided starting paper: Flynn et al. (2018), “Pan-cancer machine learning predictors of primary site of origin and molecular subtype.” https://doi.org/10.1101/333914

