# Research plan

## Recommended question
Can an uncertainty-aware hierarchical classifier trained on TCGA bulk RNA-seq reduce clinically severe tissue-of-origin errors and retain useful performance on independent cohorts?

## Minimum contribution
- Leakage-safe TCGA benchmark.
- Flat vs hierarchical classifier comparison.
- Macro-F1, per-class recall, confusion severity, calibration, and external validation.
- Frozen, reproducible preprocessing and model pipeline.

## What is not novel enough
“Several models classified TCGA cancer types with high accuracy.” This has already been reported many times and is not a sufficient thesis contribution.

## Experiments to complete
1. Flat baseline models: logistic regression, linear SVM, random forest.
2. Sensitivity analysis for feature count: 500 / 1,000 / 2,000 genes.
3. Hierarchical family → cancer model.
4. Confidence calibration and selective prediction (future extension).
5. At least one fully independent external validation cohort.
6. Class-specific and biological error analysis.

## Reporting requirements
- Record dataset release date, exact URLs and checksums.
- State inclusion/exclusion criteria.
- Fit every transform on training samples only.
- Report class distribution and excluded classes.
- Report macro-F1 and per-class metrics, not accuracy alone.
- Treat metastatic/FFPE/external cohorts as distribution shift, not as interchangeable test data.
