# Optional notebooks

The project is runnable without notebooks. Use notebooks only for inspection, visualizations, and narrative analysis after the numbered scripts have produced files.

Suggested notebook names:
- `01_data_audit.ipynb`
- `02_preprocessing_experiments.ipynb`
- `03_error_analysis.ipynb`
- `04_feature_stability.ipynb`

Keep final preprocessing and training logic in `src/` and `scripts/` so it remains reproducible from the command line.
