from __future__ import annotations
import sys; from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import requests
from pancancer.common import project_root, load_config, ensure_dirs, sha256, utc_now, write_json

def download(url, destination):
    if destination.exists() and destination.stat().st_size > 1000:
        print(f"Reusing existing file: {destination.name}")
        return
    print(f"Downloading {url}\n  -> {destination}")
    with requests.get(url, stream=True, timeout=(30, 600), headers={"User-Agent":"pan-cancer-thesis-starter/0.1"}) as r:
        r.raise_for_status()
        with open(destination, "wb") as f:
            for chunk in r.iter_content(chunk_size=1024 * 1024):
                if chunk: f.write(chunk)

if __name__ == "__main__":
    ensure_dirs(); cfg=load_config(); root=project_root(); raw=root/"data/raw"; records=[]
    for name, info in cfg["datasets"].items():
        dest=raw/info["filename"]
        download(info["url"], dest)
        records.append({"name":name,"url":info["url"],"file":str(dest.relative_to(root)),"bytes":dest.stat().st_size,"sha256":sha256(dest),"downloaded_or_verified_at_utc":utc_now()})
    write_json(records, raw/"download_manifest.json")
    print("Done. Provenance manifest written to data/raw/download_manifest.json")
