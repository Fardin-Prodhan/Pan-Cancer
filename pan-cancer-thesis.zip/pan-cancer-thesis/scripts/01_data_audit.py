from __future__ import annotations
import sys; from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import matplotlib.pyplot as plt
from pancancer.common import project_root, load_config, ensure_dirs, write_json
from pancancer.data import read_expression, read_phenotype

if __name__ == "__main__":
    ensure_dirs(); root=project_root(); cfg=load_config(); raw=root/"data/raw"; out=root/"outputs"
    expr=read_expression(raw/cfg["datasets"]["expression"]["filename"])
    pheno, meta=read_phenotype(raw/cfg["datasets"]["phenotype"]["filename"],cfg)
    overlap=expr.index.intersection(pheno.sample_id)
    counts=pheno[pheno.sample_id.isin(overlap)].cancer_type.value_counts().sort_values(ascending=False)
    summary={"expression_samples":int(expr.shape[0]),"expression_genes":int(expr.shape[1]),"expression_missing_fraction":float(expr.isna().mean().mean()),"phenotype_rows":int(len(pheno)),"matched_samples":int(len(overlap)),"cancer_classes_matched":int(counts.size),"label_counts":counts.to_dict(),**meta}
    write_json(summary,out/"metrics/audit_summary.json")
    counts.to_csv(out/"metrics/class_distribution.csv",header=["n_samples"])
    ax=counts.sort_values().plot.barh(figsize=(10,max(6,len(counts)*.3)),color="#2c7fb8")
    ax.set_xlabel("Matched samples"); ax.set_ylabel("Cancer type"); ax.set_title("TCGA Pan-Cancer label distribution")
    plt.tight_layout(); plt.savefig(out/"figures/class_distribution.png",dpi=220); plt.close()
    print("Audit complete. Read outputs/metrics/audit_summary.json before preparing data.")
