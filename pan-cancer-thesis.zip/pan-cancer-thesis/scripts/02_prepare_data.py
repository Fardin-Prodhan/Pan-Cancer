from __future__ import annotations
import sys; from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import pandas as pd
from sklearn.model_selection import train_test_split
from pancancer.common import project_root, load_config, ensure_dirs, write_json
from pancancer.data import read_expression, read_phenotype

if __name__ == "__main__":
    ensure_dirs(); root=project_root(); cfg=load_config(); raw=root/"data/raw"; processed=root/"data/processed"; out=root/"outputs"
    expr=read_expression(raw/cfg["datasets"]["expression"]["filename"])
    pheno,_=read_phenotype(raw/cfg["datasets"]["phenotype"]["filename"],cfg)
    if (pheno.sample_type != "UNKNOWN").any():
        pheno=pheno[pheno.sample_type.isin(cfg["primary_tumor_values"])].copy()
    merged=pheno.set_index("sample_id").join(expr, how="inner")
    # Drop rows that contain only missing values and genes with no usable data.
    y=merged.pop("cancer_type")
    if "sample_type" in merged.columns:
        merged.pop("sample_type")
    merged=merged.loc[:, merged.notna().any(axis=0)]
    counts=y.value_counts(); keep=counts[counts>=cfg["min_samples_per_class"]].index
    excluded=counts[~counts.index.isin(keep)].to_dict(); y=y[y.isin(keep)]; X=merged.loc[y.index]
    # Median imputation is fitted later inside model pipelines. Here remove all-NaN genes only.
    temp_size=cfg["validation_fraction"]+cfg["test_fraction"]
    X_train,X_temp,y_train,y_temp=train_test_split(X,y,test_size=temp_size,stratify=y,random_state=cfg["random_seed"])
    test_share=cfg["test_fraction"]/temp_size
    X_val,X_test,y_val,y_test=train_test_split(X_temp,y_temp,test_size=test_share,stratify=y_temp,random_state=cfg["random_seed"])
    # Leakage-safe memory prefilter: rank variance on training samples only, then apply the same genes everywhere.
    train_variance=X_train.var(axis=0, skipna=True).sort_values(ascending=False)
    selected_genes=train_variance.head(min(cfg["prefilter_genes"], len(train_variance))).index
    X_train=X_train.loc[:, selected_genes]; X_val=X_val.loc[:, selected_genes]; X_test=X_test.loc[:, selected_genes]
    for split,xx,yy in [("train",X_train,y_train),("validation",X_val,y_val),("test",X_test,y_test)]:
        xx.to_pickle(processed/f"X_{split}.pkl"); yy.rename("cancer_type").to_csv(processed/f"y_{split}.csv",header=True)
    report={"n_samples":int(len(y)),"n_genes_before_pipeline_filter":int(X.shape[1]),"classes_kept":sorted(map(str,keep)),"excluded_classes_below_minimum":excluded,"split_sizes":{"train":len(y_train),"validation":len(y_val),"test":len(y_test)},"primary_tumor_filter_applied":bool((pheno.sample_type != "UNKNOWN").any())}
    write_json(report,out/"metrics/preparation_report.json")
    print("Prepared leakage-safe train/validation/test splits in data/processed/.")
