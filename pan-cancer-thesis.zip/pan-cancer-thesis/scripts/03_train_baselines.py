from __future__ import annotations
import sys; from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import pandas as pd, joblib
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier
from pancancer.common import project_root, load_config, ensure_dirs, write_json
from pancancer.evaluation import evaluate_predictions, save_confusion

def load(split, root):
    X=pd.read_pickle(root/f"data/processed/X_{split}.pkl")
    y=pd.read_csv(root/f"data/processed/y_{split}.csv",index_col=0).iloc[:,0]
    return X,y

if __name__ == "__main__":
    ensure_dirs(); root=project_root(); cfg=load_config(); Xtr,ytr=load("train",root); Xva,yva=load("validation",root); Xte,yte=load("test",root)
    # Validation is concatenated only after all fixed choices are established in this config.
    Xfit=pd.concat([Xtr,Xva]); yfit=pd.concat([ytr,yva]); labels=sorted(yfit.unique())
    common=[("imputer",SimpleImputer(strategy="median")),("scaler",StandardScaler()),("select",SelectKBest(f_classif,k=min(cfg["features_to_keep"],Xfit.shape[1])))]
    models={
      "logistic_regression": LogisticRegression(max_iter=3000,C=1.0,class_weight="balanced",n_jobs=-1),
      "linear_svm": LinearSVC(C=1.0,class_weight="balanced"),
      "random_forest": RandomForestClassifier(n_estimators=400,class_weight="balanced_subsample",n_jobs=-1,random_state=cfg["random_seed"],max_features="sqrt")
    }
    summary=[]; reports=[]
    for name,model in models.items():
        pipe=Pipeline(common+[("model",model)])
        print(f"Training {name}..."); pipe.fit(Xfit,yfit); pred=pipe.predict(Xte)
        metrics,report=evaluate_predictions(yte,pred,labels=labels)
        metrics["model"]=name; metrics["features_to_keep"]=cfg["features_to_keep"]; summary.append(metrics)
        report["model"]=name; report["class_or_average"]=report.index; reports.append(report.reset_index(drop=True))
        joblib.dump(pipe,root/f"outputs/models/{name}.joblib")
        save_confusion(yte,pred,labels,root/f"outputs/figures/baseline_confusion_matrix_{name}.png",name)
    pd.DataFrame(summary).sort_values("macro_f1",ascending=False).to_csv(root/"outputs/metrics/baseline_summary.csv",index=False)
    pd.concat(reports).to_csv(root/"outputs/metrics/baseline_per_class.csv",index=False)
    write_json({"labels":labels,"test_samples":int(len(yte)),"note":"Models were fit on train+validation only after fixed settings were established; held-out test was never fit."},root/"outputs/metrics/baseline_run_metadata.json")
    print("Baseline training complete. Read outputs/metrics/baseline_summary.csv.")
