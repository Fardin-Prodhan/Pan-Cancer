from __future__ import annotations
import sys; from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import pandas as pd, joblib
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from pancancer.common import project_root, load_config, ensure_dirs, write_json
from pancancer.evaluation import evaluate_predictions, save_confusion

def load(split,root):
    return pd.read_pickle(root/f"data/processed/X_{split}.pkl"),pd.read_csv(root/f"data/processed/y_{split}.csv",index_col=0).iloc[:,0]
def make_model(k):
    return Pipeline([("imputer",SimpleImputer(strategy="median")),("scaler",StandardScaler()),("select",SelectKBest(f_classif,k=k)),("model",LogisticRegression(max_iter=3000,class_weight="balanced",n_jobs=-1))])

if __name__ == "__main__":
    ensure_dirs(); root=project_root(); cfg=load_config(); Xtr,ytr=load("train",root); Xva,yva=load("validation",root); Xte,yte=load("test",root)
    Xfit=pd.concat([Xtr,Xva]); yfit=pd.concat([ytr,yva]); fmap=cfg["family_map"]
    usable=yfit[yfit.isin(fmap)].index; Xfit=Xfit.loc[usable]; yfit=yfit.loc[usable]; yfam=yfit.map(fmap)
    k=min(cfg["features_to_keep"],Xfit.shape[1]); family_model=make_model(k); family_model.fit(Xfit,yfam)
    child_models={}
    for family in sorted(yfam.unique()):
        idx=yfam[yfam==family].index; yy=yfit.loc[idx]
        if yy.nunique()<2: continue
        m=make_model(k); m.fit(Xfit.loc[idx],yy); child_models[family]=m
    test_idx=yte[yte.isin(fmap)].index; Xtest=Xte.loc[test_idx]; ytrue=yte.loc[test_idx]
    predicted_family=family_model.predict(Xtest); predicted=[]
    for sid,fam in zip(Xtest.index,predicted_family):
        predicted.append(child_models[fam].predict(Xtest.loc[[sid]])[0] if fam in child_models else yfit[yfam==fam].mode().iloc[0])
    labels=sorted(yfit.unique()); metrics,report=evaluate_predictions(ytrue,predicted,labels=labels)
    family_accuracy=float((ytrue.map(fmap).to_numpy()==predicted_family).mean())
    metrics.update({"organ_family_accuracy":family_accuracy,"n_families":int(yfam.nunique()),"n_fine_classes":int(yfit.nunique())})
    write_json(metrics,root/"outputs/metrics/hierarchical_summary.json"); report.to_csv(root/"outputs/metrics/hierarchical_per_class.csv")
    save_confusion(ytrue,predicted,labels,root/"outputs/figures/hierarchical_confusion_matrix.png","Hierarchical classifier")
    joblib.dump({"family_model":family_model,"child_models":child_models,"family_map":fmap,"labels":labels},root/"outputs/models/hierarchical_classifier.joblib")
    print("Hierarchical training complete. Read outputs/metrics/hierarchical_summary.json.")
