"""External validation template.

This script intentionally requires curated external expression and label files.
It does NOT automatically label an external cohort, correct batches using test data,
or retrain on the external test set. Those shortcuts invalidate external validation.
"""
from __future__ import annotations
import sys; from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import pandas as pd, joblib
from pancancer.common import project_root
from pancancer.evaluation import evaluate_predictions, save_confusion

ROOT=project_root()
# Change these after placing correctly curated files under data/external/.
EXPRESSION_FILE=ROOT/"data/external/external_expression_samples_by_genes.csv"
LABEL_FILE=ROOT/"data/external/external_labels.csv"  # required columns: sample_id,cancer_type
MODEL_FILE=ROOT/"outputs/models/logistic_regression.joblib"

if __name__ == "__main__":
    if not EXPRESSION_FILE.exists() or not LABEL_FILE.exists():
        raise FileNotFoundError("Add a numeric expression CSV and curated labels CSV to data/external/, then edit this script's three path constants.")
    X=pd.read_csv(EXPRESSION_FILE,index_col=0); labels=pd.read_csv(LABEL_FILE)
    if not {"sample_id","cancer_type"}.issubset(labels.columns): raise ValueError("Labels must contain sample_id,cancer_type.")
    y=labels.set_index("sample_id").loc[X.index,"cancer_type"]
    model=joblib.load(MODEL_FILE)
    # Align exactly to training genes, filling genes absent on an external platform with NaN.
    training_genes=list(model.named_steps["imputer"].feature_names_in_)
    X=X.reindex(columns=training_genes)
    pred=model.predict(X); class_labels=list(model.named_steps["model"].classes_)
    metrics,report=evaluate_predictions(y,pred,labels=class_labels)
    print(metrics); report.to_csv(ROOT/"outputs/metrics/external_per_class.csv")
    import json
    with open(ROOT/"outputs/metrics/external_summary.json","w") as f: json.dump(metrics,f,indent=2)
    save_confusion(y,pred,class_labels,ROOT/"outputs/figures/external_confusion_matrix.png","External validation")
    print("External validation complete. Interpret this as a distribution-shift result, not a re-tuned internal test.")
