from __future__ import annotations
import hashlib, json, re
from datetime import datetime, timezone
from pathlib import Path
import yaml

def project_root() -> Path:
    return Path(__file__).resolve().parents[2]

def load_config():
    with open(project_root() / "config" / "default.yaml", encoding="utf-8") as f:
        return yaml.safe_load(f)

def ensure_dirs():
    root = project_root()
    for p in ["data/raw", "data/processed", "data/external", "outputs/figures", "outputs/metrics", "outputs/models"]:
        (root / p).mkdir(parents=True, exist_ok=True)

def sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(chunk_size), b""):
            h.update(block)
    return h.hexdigest()

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def clean_sample_id(value: str) -> str:
    # TCGA aliquot identifiers can be longer than a sample identifier; preserve first 16 chars.
    value = str(value).strip()
    return value[:16] if value.startswith("TCGA-") and len(value) >= 16 else value

def safe_filename(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name)

def write_json(obj, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, default=str)
