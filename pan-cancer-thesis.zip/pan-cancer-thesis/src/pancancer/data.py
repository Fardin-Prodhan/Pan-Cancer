from __future__ import annotations
from pathlib import Path
import pandas as pd
from .common import clean_sample_id

def read_expression(path: Path) -> pd.DataFrame:
    """Read a Xena-style gene x sample matrix and return samples x genes."""
    expr = pd.read_csv(path, sep="\t", compression="infer", index_col=0, low_memory=False)
    expr.index = expr.index.astype(str).str.split("|").str[0]
    expr = expr.loc[~expr.index.duplicated(keep="first")]
    expr.columns = [clean_sample_id(c) for c in expr.columns]
    # Matrix is genes x samples. Transpose once; numeric coercion makes non-numeric data explicit.
    expr = expr.T.apply(pd.to_numeric, errors="coerce")
    expr.index.name = "sample_id"
    return expr

def choose_column(columns, candidates, kind: str) -> str:
    lookup = {str(c).strip().lower(): c for c in columns}
    for candidate in candidates:
        if str(candidate).lower() in lookup:
            return lookup[str(candidate).lower()]
    raise ValueError(f"No usable {kind} column found. Available columns: {list(columns)}")

def read_phenotype(path: Path, cfg: dict) -> tuple[pd.DataFrame, dict]:
    pheno = pd.read_csv(path, sep="\t", compression="infer", low_memory=False)
    sid = choose_column(pheno.columns, cfg["sample_id_candidates"], "sample ID")
    label = choose_column(pheno.columns, cfg["label_column_candidates"], "label")
    try:
        sample_type = choose_column(pheno.columns, cfg["sample_type_candidates"], "sample-type")
    except ValueError:
        sample_type = None
    out = pd.DataFrame({"sample_id": pheno[sid].map(clean_sample_id), "cancer_type": pheno[label].astype(str).str.strip()})
    if sample_type:
        out["sample_type"] = pheno[sample_type].astype(str).str.strip()
    else:
        out["sample_type"] = "UNKNOWN"
    out = out.dropna(subset=["sample_id", "cancer_type"]).drop_duplicates("sample_id")
    return out, {"sample_id_column": sid, "label_column": label, "sample_type_column": sample_type, "phenotype_columns": list(pheno.columns)}
