from __future__ import annotations
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt, seaborn as sns
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, classification_report, confusion_matrix, top_k_accuracy_score

def evaluate_predictions(y_true, y_pred, labels=None, probabilities=None):
    labels = list(labels) if labels is not None else sorted(set(y_true) | set(y_pred))
    result = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "n_test_samples": int(len(y_true)),
    }
    if probabilities is not None:
        try:
            result["top_3_accuracy"] = float(top_k_accuracy_score(y_true, probabilities, labels=labels, k=min(3, len(labels))))
        except ValueError:
            result["top_3_accuracy"] = None
    report = pd.DataFrame(classification_report(y_true, y_pred, labels=labels, output_dict=True, zero_division=0)).T
    return result, report

def save_confusion(y_true, y_pred, labels, path: Path, title: str):
    cm = confusion_matrix(y_true, y_pred, labels=labels, normalize="true")
    size = max(10, min(24, len(labels) * 0.55))
    fig, ax = plt.subplots(figsize=(size, size * .85))
    sns.heatmap(cm, cmap="Blues", square=True, xticklabels=labels, yticklabels=labels, vmin=0, vmax=1, ax=ax)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title(title + " (row-normalized)")
    fig.tight_layout(); fig.savefig(path, dpi=220); plt.close(fig)
